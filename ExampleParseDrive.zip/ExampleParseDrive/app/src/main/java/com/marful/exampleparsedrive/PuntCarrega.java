package com.marful.exampleparsedrive;

public class PuntCarrega {

    private String municipi;
    private String provincia;
    private String coordinates;

    public PuntCarrega(String municipi, String provincia, String coordinates) {
        this.municipi = municipi;
        this.provincia = provincia;
        this.coordinates = coordinates;
    }


    public String getMunicipi() {
        return municipi;
    }

    public void setMunicipi(String municipi) {
        this.municipi = municipi;
    }

    public String getProvincia() {
        return provincia;
    }

    public void setProvincia(String provincia) {
        this.provincia = provincia;
    }


    public String getCoordinates() {
        return coordinates;
    }

    public void setCoordinates(String coordinates) {
        this.coordinates = coordinates;
    }

}
