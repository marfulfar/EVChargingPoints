package com.marful.exampleparsedrive;

import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class ConnectionClass {

    final static String ESTACIONS_CARREGA = "https://analisi.transparenciacatalunya.cat/resource/tb2m-m33b.json";
    static HttpURLConnection connection = null;
    static BufferedReader reader = null;
    static URL url;
    static ArrayList<String> linesParsing;

    public ConnectionClass() {

    }

    public ArrayList<String> getJson() throws MalformedURLException {

        try {
            url = new URL(ESTACIONS_CARREGA);
            connection = (HttpURLConnection) url.openConnection();
            connection.connect();
            InputStream stream = connection.getInputStream();
            reader = new BufferedReader(new InputStreamReader(stream));

            String line = "";
            linesParsing = new ArrayList<>();

            while ((line = reader.readLine()) != null) {
                linesParsing.add(line);
            }

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
            try {
                if (reader != null) {
                    reader.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    return linesParsing;

    }



    }//closes class

