package com.marful.exampleparsedrive;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.os.Build;
import android.os.StrictMode;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.net.MalformedURLException;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    final static String ESTACIONS_CARREGA = "https://analisi.transparenciacatalunya.cat/resource/tb2m-m33b.json";
    TextView tv_parsed;
    static ArrayList<PuntCarrega> puntsCarrega;
    ConnectionClass myConnection;
    LocationManager locationManager;

    private CoordinateManager locationManager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tv_parsed = (TextView) findViewById(R.id.tv_parsed);
        Button btn_parse = (Button) findViewById(R.id.btn_parse);
        final String myFilePath = "https://docs.google.com/document/d/1BAYP_FJqvngyFc8y241oZgahXPQCGofZNgL0_gzzWWc/edit?usp=sharing";
        final String myFilePathDesktop = "C:\\Users\\marca\\Desktop\\test_android_desktop.txt";
        final String openDataPath = "https://analisi.transparenciacatalunya.cat/resource/nzvn-apee.json";

        StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder().permitNetwork().build());

        myConnection = new ConnectionClass();


        btn_parse.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onClick(View view) {

                try {
                    puntsCarrega = parsePuntsCarrega(myConnection.getJson());

                } catch (MalformedURLException e) {
                    throw new RuntimeException(e);
                }


                int rand = (int) (Math.random() * 50);
                tv_parsed.setText("Municpi: " + puntsCarrega.get(rand).getMunicipi()
                        + " - Provincia: " + puntsCarrega.get(rand).getProvincia() + " - Coordenades: " + puntsCarrega.get(rand).getCoordinates());


            }
        });


    }//closes main



    private static ArrayList<PuntCarrega> parsePuntsCarrega(ArrayList<String> parseJson){
        puntsCarrega = new ArrayList<>();

        for (int i =0; i<parseJson.size();i++) {
            String municipi = parseJson.get(i).substring(parseJson.get(i).indexOf("municipi")+11,parseJson.get(i).indexOf("codimun")-3);
            String provincia = parseJson.get(i).substring(parseJson.get(i).indexOf("provincia")+12,parseJson.get(i).indexOf("codiprov")-3);
            String coordinates = parseJson.get(i).substring(parseJson.get(i).indexOf("[")+1,parseJson.get(i).lastIndexOf("]"));
            puntsCarrega.add(new PuntCarrega(municipi,provincia,coordinates));
        }

        return puntsCarrega;
    }


    private void requestLocationUpdates() {
        locationManager = new CoordinateManager(getApplication());
        locationManager.activityAttached(this);
        locationManager.addObserver(locationObserver);
    }

    private DisposableObserver<TTNewLocation> locationObserver = new DisposableObserver<TTNewLocation>() {
        @Override
        public void onNext(TTNewLocation ttNewLocation) {
            Toast.makeText(MainActivity.this, "Latitude:" + ttNewLocation.getLat() + " And Longitude:" + ttNewLocation.getLng() + " isAccurate:"
                    + ttNewLocation.getAccurate() + " Accuracy:" + ttNewLocation.getAccuracy(), Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onError(Throwable e) {

        }

        @Override
        public void onComplete() {

        }
    }
    //call for run time permission
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String permissions[], @NonNull int[] grantResults) {
        locationManager.onRequestPermissionResult(requestCode, permissions, grantResults);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        locationManager.onPermissionReceived(requestCode , resultCode);
    }

    //stop location updates
    @Override
    protected void onDestroy() {
        super.onDestroy();
        locationManager.removeObserver(locationObserver);
    }


}//closes class